﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC_First.Context;
using MVC_First.Models;
using Microsoft.EntityFrameworkCore;

namespace MVC_First.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationDbContext _context;

        public StudentController(ApplicationDbContext context) {
            _context = context;
        }
        public async Task<IActionResult> studentlist()
        {
            var students = await _context.Students.ToListAsync();
            return View(students);
        }

        //AddOrEdit Get Method
        public async Task<IActionResult> AddOrEdit(int? id) {
            ViewBag.PageName = id ==null ? "Create Employee" : "Edit Employee";
            ViewBag.IsEdit = id == null ? false : true;
            if (id == null)
            {
                return View();
            }
            else
            {
                var Student = await _context.Students.FindAsync(id);

                if (Student == null)
                {
                    return NotFound();
                }
                return View(Student);
            }
            return View();
        }


        //AddOrEdit Post Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit(int Id, [Bind("Id,FirstName,MiddleName,LastName,EmailAddress,PhoneNumber,Gender")]
Student studentData)
        {
            bool IsStudentExist = false;

            Student student = await _context.Students.FindAsync(Id);

            if (student != null)
            {
                IsStudentExist = true;
            }
            else
            {
                student = new Student();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    student.FirstName = studentData.FirstName;
                    student.MiddleName = studentData.MiddleName;
                    student.LastName = studentData.LastName;
                    student.EmailAddress = studentData.EmailAddress;
                    student.PhoneNumber = studentData.PhoneNumber;
                    student.Gender = studentData.Gender;
                    if (IsStudentExist)
                    {
                        _context.Update(student);
                    }
                    else
                    {
                        _context.Add(student);
                    }
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    throw;
                }
                return RedirectToAction(nameof(studentlist));
            }
            return View(studentData);
        }
        // Employee Details
        public async Task<IActionResult> Details(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }
            var student = await _context.Students.FirstOrDefaultAsync(m => m.Id == Id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }

        // GET: Employees/Delete/1
        public async Task<IActionResult> Delete(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }
            var student = await _context.Students.FirstOrDefaultAsync(m => m.Id == Id);

            return View(student);
        }

        // POST: Employees/Delete/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int Id)
        {
            var student = await _context.Students.FindAsync(Id);
            _context.Students.Remove(student);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(studentlist));
        }
    }
}
